<?php
$total = $_POST["total"];
$descripcion = $_POST["desc"];
if($total > 0 and $total <= 100000)
{
//aca cuando si
echo "total: ".$total;
echo "<br> descripcion: ".$descripcion;
}else
{//aca cuando no
echo "valor invalido";
}
?>